#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "async.h"
#include "utlist.h"


my_queue_t *jobthread_queue;
pthread_mutex_t mutex_queue;
//since we cannot use sleep, use condition wait here
pthread_cond_t cond_queue;

int count_thread = 0;


void* thread_func(void* args);
void async_init(int num_threads);
void async_run(void (*hanlder)(int), int args);



void async_init(int num_threads) {
    pthread_t threads[num_threads];

    my_queue_t template_queue = {
        .head = NULL,
        .size = 0
    };

    //init the queue of working thread (thread_poool)
    //jobthread_queue = (my_queue_t*)malloc(sizeof(my_queue_t));
    jobthread_queue = (my_queue_t*)malloc(sizeof(template_queue));
    jobthread_queue->head = NULL;
    jobthread_queue->size = 0;

    pthread_mutex_init(&mutex_queue, NULL);
    pthread_cond_init(&cond_queue, NULL);

    //init threads according to the thread number
    int return_code;
    for(int i = 0; i < num_threads ; i++){
        //since the thread_func is no onger concerned with number of thread this time, there's no need to avoid 0 case like in the game.
        return_code = pthread_create(&threads[i], NULL, &thread_func, NULL);
        printf("thread %d is created.\n", i);
        if(return_code){
            printf("ERROR: Failed to create thread %d\n", i);
        }
    }
    return;
    // TODO: create num_threads threads and initialize the thread pool 
}


void async_run(void (*hanlder)(int), int args) {
    //hanlder(args);
    my_item_t template_node_thread = {
        .args = args,
        .next = NULL,
        .prev = NULL,
        .handler_func = hanlder
    };

    my_item_t* thread_node;

    //thread_node = (my_item_t*)malloc(sizeof(my_item_t));
    thread_node = (my_item_t*)malloc(sizeof(template_node_thread));
    thread_node->args = args;
    thread_node->next = NULL;
    thread_node->prev = NULL;
    thread_node->handler_func = hanlder;

    pthread_mutex_lock(&mutex_queue);

    printf("existing work thread number : %d \n", jobthread_queue->size);

    //append the thread into double linked list
    DL_APPEND(jobthread_queue->head, thread_node);
    jobthread_queue->size ++;

    pthread_mutex_unlock(&mutex_queue);

    pthread_cond_signal(&cond_queue);
     // TODO: rewrite it to support thread pool 
} 


void* thread_func(void* args){
    //increase the num of threads to indicate which is the current one
    count_thread ++;
    int thread_num = count_thread;
    printf("thread %d is starting\n", count_thread);

    while(1){
        my_item_t* tmp_thread;

        pthread_mutex_lock(&mutex_queue);
        //sleep when there is no job need to handle with
        while(jobthread_queue->size == 0){
            pthread_cond_wait(&cond_queue, &mutex_queue);
            printf("thread %d is in condition waiting\n", thread_num);
        }
        //handle the job using one thread in pool
        tmp_thread = jobthread_queue->head;
        DL_DELETE(jobthread_queue->head, jobthread_queue->head);
        jobthread_queue->size --;

        pthread_mutex_unlock(&mutex_queue);

        tmp_thread->handler_func(tmp_thread->args);
        printf("thread %d is finished.\n", thread_num);
    }

}



